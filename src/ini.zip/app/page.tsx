"use client";

import "@signal-react-ui/styles";
import { useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function Home() {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === "loading") {
      return;
    }

    if (status === "unauthenticated") {
      router.replace("auth/login"); 
      return;
    }

    const roles = session?.roles || []; 

    if (roles.length > 1) {
      router.replace("/select-role"); 
    } else if (roles.includes("specialist")) {
      router.replace("/specialist/dashboard");
    } else if (roles.includes("manager")) {
      router.replace("/manager/dashboard");
    } else if (roles.includes("admin")) {
      router.replace("/admin/dashboard");
    } else {
      router.replace("/auth/login"); 
    }
  }, [status, session, router]);

  return null; 
}
