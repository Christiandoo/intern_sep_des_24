"use client";

import DashboardLayout from "@/views/components/dashboard/Dashboard";

const DashboardPage = () => {
  return (
    <div>
      <p>admin</p>
      <DashboardLayout />
    </div>
  );
};

export default DashboardPage;
