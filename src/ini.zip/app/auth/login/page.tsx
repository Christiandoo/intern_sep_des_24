import React from "react";
import Login from "@/views/auth/Login";

const LoginPage = () => {
  return <LoginPage />;
};

export default Login;
