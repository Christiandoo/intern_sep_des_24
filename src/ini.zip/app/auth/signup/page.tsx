import React from 'react'
import SignUp from '@/views/auth/SignUp'

const SignUpPage = () => {
  return <SignUp />
}


export default SignUpPage