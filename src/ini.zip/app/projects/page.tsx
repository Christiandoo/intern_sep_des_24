import React from "react";
//import { Project } from "@/views/layouts/project";
import { ProjectTable } from "@/views/layouts/projectTable";

const DashboardPage = () => {
  return <ProjectTable />;
};

export default DashboardPage;
