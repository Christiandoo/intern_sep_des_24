import React from "react";
import { ProjectTable } from "@/views/layouts/projectTable";

const DashboardPage = () => {
  return <ProjectTable />;
};

export default DashboardPage;
