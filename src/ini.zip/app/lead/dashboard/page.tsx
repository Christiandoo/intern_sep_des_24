"use client";

import DashboardLayout from "@/views/components/dashboard/Dashboard";

const DashboardPage = () => {
  return (
    <div>
      <p>lead</p>
      <DashboardLayout />
    </div>
  );
};

export default DashboardPage;
