import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  console.log("Request received:", req.method);

  try {
    const { username, email, password } = await req.json();
    console.log("Data received:", { username, email, password });

    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("Password hashed");

    const user = await prisma.user.create({
      data: {
        username,
        email,
        passwordHash: hashedPassword,
      },
    });

    console.log("User created:", user);

    return NextResponse.json({ user }, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof Error) {
      console.error("Error during user registration:", {
        message: error.message,
        stack: error.stack,
        name: error.name,
      });
    } else {
      console.error("An unknown error occurred:", error);
    }

    return NextResponse.json({ error: 'Something went wrong. Please try again later.' }, { status: 500 });
  }
}

export function OPTIONS() {
  return NextResponse.json({ message: 'OK' }, { status: 200 });
}
