import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getServerSession(authOptions);

  if (!session || !session.user?.email) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const currentDate = new Date();
    const oneMonthAgo = new Date(currentDate);
    oneMonthAgo.setMonth(currentDate.getMonth() - 1);

    const projects = await prisma.project.findMany({
      where: {
        userId: user.id,
        OR: [
          {
            start: {
              gte: oneMonthAgo,
              lte: currentDate,
            },
          },
          {
            end: {
              gte: oneMonthAgo,
              lte: currentDate,
            },
          },
        ],
      },
      select: {
        id: true,
        name: true,
        start: true,
        end: true,
        description: true,
      },
    });

    return NextResponse.json({ success: true, data: projects, totalProjects: projects.length });
  } catch (error) {
    console.error("Error fetching projects:", error);
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 });
  }
}
