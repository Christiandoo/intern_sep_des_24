import { getFile, uploadFile } from "@/lib/storage";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";
import { parseISO, startOfDay } from "date-fns";

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get("file");
    const name = formData.get("name");
    const description = formData.get("description"); // Ambil description
    const start = formData.get("dateStarted");
    const end = formData.get("dateEnded");
    const userId = formData.get("userId");
    const roleId = formData.get("roleId");
    const folder = "user/";

    // Validasi file
    if (!(file instanceof Blob)) {
      return NextResponse.json({ success: false, message: "Invalid file type" }, { status: 400 });
    }

    // Validasi nama
    if (typeof name !== "string" || !name.trim()) {
      return NextResponse.json({ success: false, message: "Invalid project name" }, { status: 400 });
    }

    // Validasi description
    if (typeof description !== "string" || !description.trim()) {
      return NextResponse.json(
        { success: false, message: "Description is required" },
        { status: 400 }
      );
    }

    // Validasi tanggal
    const startDate = startOfDay(parseISO(start as string));
    const endDate = startOfDay(parseISO(end as string));

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      return NextResponse.json({ success: false, message: "Invalid date format" }, { status: 400 });
    }

    // Validasi userId dan roleId
    if (typeof userId !== "string" || typeof roleId !== "string") {
      return NextResponse.json({ success: false, message: "Invalid user or role ID" }, { status: 400 });
    }

    // Upload file ke Firebase Storage
    const path = await uploadFile(file, folder);
    const url = await getFile(path);

    // Simpan data ke Prisma
    const project = await prisma.project.create({
      data: {
        name,
        description, // Simpan description
        workOrder: url,
        start: startDate,
        end: endDate,
        userId,
        roleId,
      },
    });

    console.log("Project created:", project);

    return NextResponse.json({
      success: true,
      name: project.name,
      message: "Project added.",
    });
  } catch (error) {
    console.error("Error uploading file:", error);
    return NextResponse.json({ success: false, message: "File upload failed" }, { status: 500 });
  }
}
