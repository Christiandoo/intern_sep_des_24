// Import NextResponse dan Prisma client
import { NextRequest, NextResponse } from "next/server";
import { prisma } from '@/lib/prisma';
import { uploadFile, deleteFile } from "@/lib/storage";
import { parseISO, startOfDay } from "date-fns";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        {
          success: false,
          message: "ID is required",
          data: null,
        },
        {
          status: 400,
        }
      );
    }
    console.log("ID from request:", id);

    const project = await prisma.project.findUnique({
      where: { id },
      include: {
        userRole: {
          include: {
            user: {
              select: {
                username: true, 
              },
            },
          },
        },
      },
    });

    if (!project) {
      return NextResponse.json(
        {
          success: false,
          message: "Project not found!",
          data: null,
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json(
      {
        success: true,
        message: "Project details retrieved successfully",
        data: project,
      },
      {
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error retrieving project:", error);
    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while retrieving the project",
        data: null,
      },
      {
        status: 500,
      }
    );
  }
}


export async function PATCH(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        {
          success: false,
          message: "ID is required",
        },
        {
          status: 400,
        }
      );
    }

    const formData = await request.formData();
    const file = formData.get("file");
    const name = formData.get("name");
    const description = formData.get("description");
    const start = formData.get("dateStarted");
    const end = formData.get("dateEnded");
    const userId = formData.get("userId");
    const roleId = formData.get("roleId");
    const folder = "user/";

    if (name && (typeof name !== "string" || !name.trim())) {
      return NextResponse.json(
        { success: false, message: "Invalid project name" },
        { status: 400 }
      );
    }

    if (description && (typeof description !== "string" || !description.trim())) {
      return NextResponse.json(
        { success: false, message: "Description is required" },
        { status: 400 }
      );
    }

    // Validasi tanggal
    let startDate, endDate;
    if (start && end) {
      startDate = startOfDay(parseISO(start as string));
      endDate = startOfDay(parseISO(end as string));
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return NextResponse.json(
          { success: false, message: "Invalid date format" },
          { status: 400 }
        );
      }
    }

    // Validasi userId dan roleId
    if ((userId && typeof userId !== "string") || (roleId && typeof roleId !== "string")) {
      return NextResponse.json(
        { success: false, message: "Invalid user or role ID" },
        { status: 400 }
      );
    }

    const existingProject = await prisma.project.findUnique({ where: { id } });
    if (!existingProject) {
      return NextResponse.json(
        { success: false, message: "Project not found!" },
        { status: 404 }
      );
    }

    let filePath = existingProject.workOrder;
    if (file instanceof Blob) {
      if (filePath) {
        await deleteFile(filePath);
      }

      filePath = await uploadFile(file, folder);
    }

    const updatedProject = await prisma.project.update({
      where: { id },
      data: {
        name: name || undefined,
        description: description || undefined,
        workOrder: filePath || undefined,
        start: startDate || undefined,
        end: endDate || undefined,
        userId: userId || undefined,
        roleId: roleId || undefined,
        updatedAt: new Date(),
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Project updated successfully",
        data: updatedProject,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error updating project:", error);
    return NextResponse.json(
      {
        success: false,
        message: "Failed to update project",
        error: error.message,
      },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json(
      {
        success: false,
        message: "ID is required",
        data: null,
      },
      {
        status: 400,
      }
    );
  }

  try {
    const project = await prisma.project.findUnique({
      where: { id },
      select: {
        workOrder: true,
      },
    });

    if (!project) {
      return NextResponse.json(
        {
          success: false,
          message: "Project not found",
          data: null,
        },
        {
          status: 404,
        }
      );
    }

    if (project.workOrder) {
      await deleteFile(project.workOrder);
    }

    await prisma.project.delete({
      where: { id },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Data Post Deleted!",
      },
      {
        status: 200,
      }
    );
  } catch (error: any) {
    console.error("Error deleting project:", error);
    return NextResponse.json(
      {
        success: false,
        message: "Failed to delete data! Project not found or invalid ID.",
        error: error.message,
      },
      {
        status: 500,
      }
    );
  }
}