import { ProjectEdit } from "@/views/layouts/projectEdit";
import React from "react";

const DashboardPage = () => {
  return <ProjectEdit />;
};

export default DashboardPage;
