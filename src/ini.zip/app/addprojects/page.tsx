import React from "react";
import { Project } from "@/views/layouts/project";

const DashboardPage = () => {
  return <Project />;
};

export default DashboardPage;
